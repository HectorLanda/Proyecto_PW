<!-- resources/views/cartas/modificar.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Carta</title>
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const previewContainer = document.getElementById('image-preview');
                const imageElement = document.getElementById('preview-img');
                
               
                previewContainer.style.display = 'block';
                imageElement.src = e.target.result;
            };
            
            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</head>
<body>

<h1>Actualizar Carta</h1>

<form action="<?php echo e(route('cartas.update', $carta->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" id="nombre" value="<?php echo e($carta->nombre); ?>" required>
    <br>

    <label for="descripcion">Descripción</label>
    <textarea name="descripcion" id="descripcion"><?php echo e($carta->descripcion); ?></textarea>
    <br>

    <label for="precio">Precio</label>
    <input type="number" name="precio" id="precio" value="<?php echo e($carta->precio); ?>" step="0.01" min="0" required>
    <br>

    <label for="categoria_id">Categoría</label>
    <select name="categoria_id" id="categoria_id" required>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categoria->id); ?>" <?php if($categoria->id == $carta->categoria_id): ?> selected <?php endif; ?>><?php echo e($categoria->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>

    <label for="stock">Stock</label>
    <input type="number" name="stock" id="stock" value="<?php echo e($carta->stock); ?>">
    <br>

    <label for="imagen">Imagen</label>
    <input type="file" name="imagen" id="imagen" onchange="previewImage(event)">
    <br>

    
    <div id="image-preview" style="display: none;">
        <h3>Vista previa de la imagen:</h3>
        <img id="preview-img" src="<?php echo e(asset('storage/' . $carta->imagen)); ?>" alt="Vista previa de la imagen" style="max-width: 300px;">
    </div>
    <br>

    <button type="submit">Actualizar</button>
</form>

<a href="<?php echo e(route('cartas.pokedex')); ?>">Volver</a>

</body>
</html>
<?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/cartas/modificar.blade.php ENDPATH**/ ?>