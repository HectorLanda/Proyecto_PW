<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - Cartas</title>
    <link rel="stylesheet" href="<?php echo e(asset('diseño.css')); ?>">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="navbar-brand">Poke-Store</div>
            <ul class="navbar-menu">
                <li><button onclick="agregarCarta()">Agregar Carta</button></li>
                <li><button onclick="verCartas()">Ver Cartas</button></li>
                <li><button onclick="venderCartas()">Vender Cartas</button></li>
                <li><button onclick="ventas()">Ventas/Pedidos</button></li>
                <li><button onclick="edit()">Actualizar/Eliminar</button></li>
                <li><button onclick="loginUser()">Login</button></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Bienvenido al Administrador de Cartas</h1>
        <p>Selecciona una opción en la barra superior para empezar.</p>
    </main>

    <script>
        function agregarCarta() {
            window.location.href = "<?php echo e(route('cartas.create')); ?>";
        }

        function verCartas() {
            window.location.href = "<?php echo e(route('cartas.lista')); ?>";
        }

        function venderCartas() {
            window.location.href = "<?php echo e(route('ventas.create')); ?>"; 
        }

        function ventas() {
            window.location.href = "<?php echo e(route('ventas.realizadas')); ?>"; 
        }

        function edit() {
            window.location.href = "<?php echo e(route('cartas.pokedex')); ?>"; 
        }

        function loginUser() {
            window.location.href = "<?php echo e(route('login')); ?>"; 
        }
    </script>
</body>
</html>
<?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/cartas/index.blade.php ENDPATH**/ ?>