<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Cartas</title>
    <link rel="stylesheet" href="<?php echo e(asset('boob.css')); ?>">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1 class="mb-4">Listado de Cartas</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $cartas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card" style="width: 18rem;">
                  
                    <?php if($carta->imagen): ?>
                        <img src="<?php echo e(asset('storage/' . $carta->imagen)); ?>" class="card-img-top" alt="<?php echo e($carta->nombre); ?>">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/150" class="card-img-top" alt="No Image">
                    <?php endif; ?>
                
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($carta->nombre); ?></h5>
                        <p class="card-text"><?php echo e($carta->descripcion); ?></p>
                    </div>
                   
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Precio: $<?php echo e($carta->precio); ?></li>
                        <li class="list-group-item">Categoría: <?php echo e($carta->categoria->nombre); ?></li>
                        <li class="list-group-item">Stock: <?php echo e($carta->stock); ?></li>
                    </ul>
                    
                   
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/cartas/lista.blade.php ENDPATH**/ ?>