<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas Realizadas</title>
    <link rel="stylesheet" href="<?php echo e(asset('Pedidos.css')); ?>">
</head>
<body>
    <h1>Ventas Realizadas</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pedido->id); ?></td>
                    <td><?php echo e($pedido->cliente->nombre); ?></td> <!-- Nombre del cliente -->
                    <td><?php echo e($pedido->fecha); ?></td>
                    <td>$<?php echo e(number_format($pedido->total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('ventas.create')); ?>">Registrar Nueva Venta</a><br><br>
    <a href="<?php echo e(route('dashboard')); ?>">Volver</a><br><br><br>
</body>
</html>
<?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/ventas/realizadas.blade.php ENDPATH**/ ?>