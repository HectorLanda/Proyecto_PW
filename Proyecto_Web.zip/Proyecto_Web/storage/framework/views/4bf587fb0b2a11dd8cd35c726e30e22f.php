<!-- resources/views/cartas/pokedex.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cartas Pokémon</title>
    <link rel="stylesheet" href="<?php echo e(asset('jorge.css')); ?>">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            <?php if(session('error')): ?>
                alert("<?php echo e(session('error')); ?>");
            <?php endif; ?>
        });
    </script>
</head>
<body>

<h1>Cartas Pokémon</h1>

<?php if(session('success')): ?>
    <div><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Stock</th>
            <th>Imagen</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cartas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($carta->nombre); ?></td>
            <td><?php echo e($carta->descripcion); ?></td>
            <td><?php echo e($carta->stock); ?></td>
            <td>
                <?php if($carta->imagen): ?>
                    <img src="<?php echo e(asset('storage/' . $carta->imagen)); ?>" alt="<?php echo e($carta->nombre); ?>" style="max-width: 100px;">
                <?php else: ?>
                    No hay imagen
                <?php endif; ?>
            </td>
            <td>
                <form action="<?php echo e(route('cartas.destroy', $carta->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta carta?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Borrar</button>
                </form>
                <a href="<?php echo e(route('cartas.modificar', $carta->id)); ?>">Actualizar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<a href="<?php echo e(route('cartas.create')); ?>">Agregar nueva carta</a><br>
<a href="<?php echo e(route('dashboard')); ?>">Volver</a><br>
</body>
</html>
<?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/cartas/pokedex.blade.php ENDPATH**/ ?>