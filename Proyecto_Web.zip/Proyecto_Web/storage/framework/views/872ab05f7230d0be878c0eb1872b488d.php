<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex min-h-full flex-col justify-center px-6 py-12 lg:px-8">
        <div class="sm:mx-auto sm:w-full sm:max-w-sm">
            <img class="mx-auto h-10 w-auto" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATMAAACkCAMAAADMkjkjAAABwlBMVEX////8yxKnEBMiLF/rHCQxYqUgWaHxGyGuvtgGGFWuscELKV2dJEGqDg15ID8WLWErTYoxZqajAAD/zwArca0ua6kyZKU2XaC/mQCxAAArcq3EmwCfAAA1X6GmAAAwaacZUYkaSoDmxMXy9fP99/fEFRver7CLpsrgt7gZU4sYWpOHn8eCjKkTH1gaRHm4xt3Yo6SWma4oQnzy39/Ebm/g5+rxwg/gtAu+ITauJijt0NGxurrSk5TPpgZ5f2rKgYGxODqPGCm2RkjTCxTBAAi5WFpZdoXYrgkAQ34AMWyrpWJugnUbWKj57OyvMDLDa2yxlBpadJrlwCcAKGg6ZpvJ2egVZa+pkTrTtT0ydKO2pVbBrVCVj1KaikHbujKlnGSQlXXJs0dIYXnNiIm5UFFujrKSqcN+gmBSc4lte3JSeq9GZI9ojrzX4e308ubm6OI6X5V7i5idpaPV1MDy7tgvWYSzs5ri2rFTcKR8fG1lcYD68s6OhFtldntJbY9wiJZqeJeVmYNNa6WskyiztaBGe50AP4hIYW1WZFaRqbg0WXxqcFVfYTeXiERTgZWMhVAiM1tmZ1mBkXOQmGdnKFBWJk0G6M1/AAAgAElEQVR4nO2di1/bRvbojROpNLtuIhsbgfALE2I7KdAA9oViyI+nCYYAMQIn4VXCKw6/su2yd5Mbk3RZuttuQ/Y2v/v/3nPOjKSRbF4J3TStz+cTMLI0Gn11njMjxeWqSlWqUpWqVOVXLt21H7oHH5vENsLy3IfuxMclG8lkWPHHPnQ3PiKJ5bPJcDgcePqhO/IRyUwEkYXDUtU6zyrrWYYsrChV6zybbBjIwDpvfujOfBxSm02EFdAxXUHrbP/Q3fkYZC4bIbPMP1IQWrhqnafKToT8v6Ivaps6fqha52nSnYiSM9Mfaaq2JVWt8wxSjCbQIvUVX0ZVp/Po16qZ7ckyk02gF9NHfTUpVdUW0ToD6x+6V79qWc9GFGCm7NeApAFafwCgyVXrPF42slEFJTzrQ2hjqqruV63zRGkfJ2QBfYGQ1dRAGJhXqnXnCTKXbUsiM/0uR1ZTM73NyoHfu3XO7VTe3m0g+44j881+p2CyoUjKxu/UOLtrn2zAz3W58mBFdwRDJiAb9XFi/RJVTwHlxu+TGACTZLnWtRFJKIGKllakkKlI+ZShYzqVUNLN7pMajpXJL3QF/2HZ2Xgiy1IgINUWs4lAAKBtlO3zivl/JbDkIx3TSccU+ekxlsyke71OoapU4RIOJ38V0P6by7sdvXPjb8iL5Ek0QvanlEG7Nd6m4IVLD31AbMLQsScnjjnGNrLJOr9DlBPV8peXr7+88sWrmfzubjC4u1t89advvvz2z+dCN3cjLEsGsUBgNxoJMH2Q7bn9BkemhJGYzonVOW242ybte9G9vBOZX/lwQ7ux7iuvgjJKvSn01/433/75bC203wzIQQsYyF40wZkp0oxgQ+332xLMvKTt7wxifudU3c6MRBKgH2DjZbyIWbnd/0ckdmV910YLJMgFyO3/5VRqsfaniqhhEmcWQGb0Qyp8bey8M94WjSQ5NIn5pzJiMairOBZkWpEXyY2K/fllLTZ2ZcbJS2SG2HLFv5xkot3tT2VZ4CXp+VGFmEUQVyCfl5BOkkPrBmSGo+OOPKw8ublRuyOqYjYbSRzHbF7lUoA/KtUMtUml8Wnt3C8UHnbW6x28ZENEbnLpfx/XQjtkFUFTxcCMituLqpbHDXtoUYq+OM2gKd+yI4rZKDBLCsEPAyEcGX7ablzmTDQSSTLjE4ShqzOQaYfwV2N5j/IQKzBY1D250X7RChe78le7/8rlgsXnpWf9m5ubz7afF9HBcXCyXNlAd2auMY9DwGRpf/NA1aBu3McNSWSmlzSNoMH3X7LTRtqQSF5kxqedpPANdpF5g1l4VJACQgsf1qRQxlSthH86qcyMg+XXkSDxC1W42IagYnJO3n2+uTitZUA0EPo9/Xo7L8uMWm77/5Q10f1qPJJk2iVJcr70Bnhl0jUpzow47uMYz3RRQmuVv2GHZU1/ZmPGggEWTrEICFlkQRPkkY6KN8EqBzjLplIhcEajJjMOzu8HhTsx8Ts/MTlXv/XiQM0QqTEU4EXKr2W0xedc1+StMmh7eEsNiwQvo42l+NWMGszkJR+HhnYq/4kc41zESkuVAIsEJjupcc61kwVmpGZbmmrJPDIzano4CzJUnNEj4mBmgGt8uvF+CicQy9U/f60Cq3QqVSNKKpXOELb5ffkYaMU2zkxeRAUzjwer4czkZR+NJqoqaB4mai8BWvdNk5ekh/e3StvbpdH9sC4xbIr8Q7vBTF8xBz1qVHUar11f9Rl/H+gVAuceMEsYoJzgntx4VwfX/jfZ9GH7L6aRV01lAWxgEy+CpGryc4dPe2XomXxga0DVthkziVXgKYKmU3Kx9eebQYknbdJ+//y0yuxOnV7czuucWgHcGYVN/YHFDNwkBkr/rPk3MXQGzt02zqzwun+UDhC5oVp2n99Qu59YxErzmbHjeHFqoGuZ6SKpWu6745gt+ECsq9P6WVAI8OsToRV3uY7ppXnS44zpCdQ3BZ1By/MQoC9YPYHbNwoOrGD9TcmGM3AWTWbY4gGC03XOrbGu7oZrI4GGWnsebhs5jkyufzZ9CjC6XlK15wRNtqcct0xmq6nVlZIJTdM2dbLMh8Ymgjaqc//FBoGmBWuuIUegauom92t5xkwR+pdWtRXFr7w02oTAOYr7OKwNUhli5j/kdwL08XX/VgF0Epk1JrNJZqjI7UwObu5vOUPHnk0fa5IVVG0LodUXbS7tC2SGSYQ0A/E1LOjZG2Qmb1uql9JMaGwM6HXZyVNE7aDAoCXzEDbDBZ/wvaou6oKHA4YTiNWhMCazI18qPZZRDXAHjyaQWR0YvaFzZ9O3dYNYrjSdPhMwfsGaWkSfJv+lMjNM0gImhIz6GphJRUcbGBq4km2lfeWnIWqauh9gARR5vLQzm9YFDweB8wXu4yjtiVkjMSN3IYArIKpkhDMjOV3fXn3Pke3Pn50Yh3ZAcWBXVLQrFjNUK8M5A7NFYCYv2LmgprFEVp+oMb/y2TzhmMonnxgzMWxSEGgM60sCw0Xwb2FHlW76s7rCxF2jSwBOwxwYtiYjjXUCNPwDjPbYzPfWeBtD1n8uYtQ/LfMMrVP++/HMzKvJqPNSQH7rVKWMOkp6pvcb3/h8sw9WVpZXLYToB14ETGYPfLbjtS1Ft/4GvUN/5phDnmljeoamJ8zPoClvIjN/Er8slMDBEbg6/lOpWO0DsrZrxOx5Jcs4UeCMagAV7ZVQrrfbma1a3vlAkrbKzuErscg5aiJb2MrpKP63JrW09lo3bdNSKtasNqEXxORDbcRSoQIznlnoDwWPCjkxWSWGAP8EeLjF/iMGjlTOX2kk7ov7bSAsj31wbmgZlSlaUMjR5gxmNG5mRckxdTogzTpb8PWzuBk2vvGtyDQUhHAOzY0PjYIAzM5vixNw35Z1Kzqj3mGV7ncwA38W2WX64xdSFVTLRjO9fcQjw/wmKBwz00pqdoWYRQna7tkipiBgnfPATJK/tVrcoVyj/tq1aBCZ3bUi2rRcdld837GoadqLbztHWRwOJtb5C6xHvoWwwOzQ1kgKM/+3ovOjKj1gJRux7p25mb29ts8///zSLqIRbxwiNnPb2ZQZGdTpCTTOiqYJEcVklls5RdHIMYveuQbK0SIy+0Zk1pb9/vvbbdEoKpr8QmDWX4bsbY6lsoZx+V4AMmn3H//8J2RZdZyFb5YjSyIzpWRvBS5RtDbQu5+t4e3Y3A9gaXAYEMnvtSXht79RVA00bQMZuxkUGQDbUd0xpkmXCMw4tDLTsV3g7N3t/eL+6MqC2MPM83pg9ierwe77uzfnbmWjUaZn31nMMmUtLsssmdWX+V5LUPvL63//9u/f5cE2JzgyIzuLIjPdcWc1NVMQPJxYpf/3DwWmr7xYamwEk7NqBo74Da8H/D+bDadSUIIdZ5ouFgSi0dPDwFIpl6Ohakk/WrLSIXRoUv0roUEMzxA8o1GqBkrWrmXI7soBxswop2qgMZkWNT5V/IaXSpnIaCRIdxg4WNeEqDno1alKj/0QFqcLTK9ls20y7UqxYdN/rGnCJZKecUV7eCw032KuHo0N3bPiN6OhlukHZsFXthZjEDyhzYRVkNO9c7b4QOZFkxlO07twDvRETyW/csj34+lsEhokZkv2ZiB7eyj+bVTp7Y3OCQPO7KXtGsEMeRAQ/VwavNyxpkk6gcwipGi7xyGrSU8H4XpAz2gwuc5oP0PM6nk6FPtyY/2vu4FAfqb444848h+Q9o+7C76HaJjEzDQ3FapeHJK4IYcV7v9rtniWAcyYP3N2TLWXD7xK9zMd0+uO+h/Nz88vvigVGDX/hGN38FyCO+PgDyhuHoeMjcUbirZ83CVCRQ7Mdv/xj32aTzRuViazjcxuIbD2GShYgxKXQB6HFKX8cchWdZp6Imbc3FIHuXoZ7KEWFNDP7N83qhujtcko6rit2qSDHKk4ePUtQ7OUw0cYA3kKsbjFoNmMG4NAGcsUxJG6403TRRmVoWj1vNbxlaEbU1/gTOW/fvrpX/sY0mYNZlsYAzZcsRsSZh3iVBN+lpxqYSBbwOHGgHyDZod5VElPA7ObrjlAxgcRfRMmMgqb4bKwWSa8SkdpfIQDCWNpXlxq2qNGDJy6WL9hzCBmop9E06w7wTRduBwTkEWCxAy75Estl6UFEElyAKf96/6f/gV5suEwM2oec432WlPD2ASVxCdtA3LFpM+3xJC1d6OiGS4qrUIPnuyAzfLmOTJheqAsbJYJQHhDdqmU1Ewabs7y9ujEAh8gUQ+d2QYGAebOBD+pHfjRNk9A5ooRM6ZoObjBy7s5uSztULVivSSBt+n/qQDhmxtx5gC1K/hXRkyWitsvXs8vvt4s5fl0cMX8BTIuiZC5duzM9qHmx3kp1rpvhZDp/du6xey0aiXFR9D8b8ZS4DT35Vz+zRJCogGSaeh7nSK6NDDdAhXvomn2o+qdYJouWsQaiSQSpGgzQKxSfpvR+hGDy/X3n/aBGf9e2ySLZMSKm9PGLCN4jxLNCcsVPKRvlk1utkM2R7MoC8YMyIsctGYkdb5lhqykaf26yWyhrDmHwM40SYwt9OckaV81PN4YQiM7FHSKBwHRnaVVrA1ONE0XLsk3mOH8Cc2ZO20qrc4DBHnO9TXpGUvRU1gGMKOUi2+0TDqNs4xseFU7oMm58oKpJsWQ4X2MhcUYoKq79XAO5rJ8d+kZFL0fB9k2zRr91AKPTUShP6RCTB4zbxUNkLz1OwGhw68TRzsy81Sjn4yMCuuEAa1yBMULgrrmhuvrf/lNj5nGcpMp2bNMigqrpYcPoL9pvFB1W8Yxbqd1pvbZKKP0pDbmehIQco2MupgLyvvsCh/qSCz8wIdj4NobBs2vHJ9C8jYOjbk7SCmha9aAyQM2FIcurc7qUwofQbC5szOZpotW5duZ1ZclCRkNEfhd335lxU2snJBZ/S5NMvkWSlJu/80su39wpQTNMQDk69elAJ9jkp8+EQeCcJQ1x1c5PtR1XSlu0ngQ3oBFKjrtw18VZGxTN6ouypCtsfR0PxypMUUTG8HpPnBnVhNpcnCnmSZOYyOzpKhozhuaVheBgLzzDUalI2aapGbQseIY/u1bgYj5QjNvl4qPK0EYsFtnBor1vC6Zk7+44sW8YlVdZIlZenS0/83BmKmAqjbvVyqM0zokxUbPyOfPY+ViJtVpbeKInmzBmCgWAxoObYgbmGnWnYYMwwAyY9BY1vGq3DgVIHDzSRjUjKVPY/tsjnM/RchKYFjPzBrJh1c6HQB7Lootkf6pi6MSKRuv0c37k+FJfRqzUGECDKEd5NmCFgOa7265b9PeoppRc2MvqNrLrRpZUaFQY4ZJQa0yNHpkuaIUjXRUXo/lkHyEM7t2mw3c5hxD91gK4HWGzRGHmhekZvXcmjDoyWb5vrBKloCTmrJNZVM41qJp05tFXeI1etn4bapsShpj3gExUwrcGaX3y8JLmgYcWRWkMmZSfoGGsDJblJelsUywOTQa3xbC8dmiJslcFpklr30/zsfTZGfGnVbfyKxGZ+WzL8MXbTC4Kq7hsOYeDw7JEqZx9qmspQxXNl3nirZ6gr0ZOBZJz5T8LFdFrXDoPErDlQfMWUFv2aiCFPhudXZhGYI9mmyKzZqILp/Gt602MvP+xtOjJpP1CDC7fX/cGux2BDxoHEt0s3xOMcvkETb1DJkZcyYpCEaAcoxWaUhSGYHUGMviNvfJswUKZXs4xfdIp/tVN2v6OL+AemmJMP4MzraOupdWD2Q2EhOQaHqhjjlhCEzITDAi6Endkc00G89mmvhEQyL5/f0iIuOzKk5nq2mQJYT1Q9ZrH5sKqN/nl/BVPYYpfkxKG8VkHgsZCBy5SomooWxbVApMnKxovhpWEyh1pvGDTglTnRNopxkqz9lG8JtFxoyv6+PBUmN6RszYDcYgYI2OY9RsPJtpgmx8//2tHderrKlozrx2TN3UFb3Er2I5x9agrfIuFpGZBL4LvYdv00+lQkY9kCoXAzWGsqm0hKp8Fs+GbOmQISuYyGrU17o1mKY14vE0DMRHxDHvyonM+ABthvwZ2abK/CEag6WwEDUbG89ompCT17a4ML01Fc2Z16ZUuLWP+FU8YMjqeSzPaIxZQO5fSM2uvlRYqQB3O4zbeENlXCD3hXSVoB2fQvhSK3xxkDAkkVI3FXOtXnoRFTVFc5uGwVJ6KDJj2zOsvJxFOncNjXxkuiEyzcYzmqYpe22mojmHICGzn+aX8dBY6shjF6i8TMwCOrphHIXHb8AH5s0g4FtaLqOGjwKzKU79ZaoSNZ8v9dZvlJu6pflptYQrGtnFaqPKEZZG84o1kItKjMUTZ2bkM9q0n+UaKfXNsqGRwk1E0zx5GKiCtAuK5gjmY0a5C1rGF9UaCzI09TWlkAE+OQn9SrG7XZTMJWfzOWXZCYaeaqUMV1LKkIKdL0zoujEWpAiDD2PqPmY9NPGRmibLyzBmhs6g4b8uyjrdxy3DqGnOBH0eJLncH4iTOxg1wTbPh8zlippTnrJjZNoYEzV8GS7ZszL1osksjGrGpnEEZimcSZfzTjCaCU3R82+XjKUa+Du1ulLQJWvUURm1Ds2oNGBMmpfBRbSzPgczqlPV+f7SVmnzwLxV5M4wPo1pWxV8qHbCvOYJsiGkG868lq6mZttAFjS9exqnh+stZsZ8rqbmIUXaZhkTxoMyarQMbYuvqNL1/e/uri7Nzi4tPFgZDVsqxkxT8HnaNI0sosdP4VpHcHUOZnQjaVhbs8a/U1g60WAQOLZyZmCaxy05OFFiWXPKs9LsnW+haCILWlUpjj3IFrPGJcN9YNxcsZiVUyNo/br5SI9uSEAAxt64IfgKXHeGAkVIep5lshlbDKCmxzK0atySMco0MBkGx1YedphpNp5/XfKtrDlNLC85W61ZNla6X0Nm5vc4NrWIo7NsLZnpPqiwfyAywycRbdTIiBaLJjXFsdYdiEWiLGwKx7xgzIAVZKlUhWbEXOMYYWpGqeN8hWr/HU2Tza1H+ezdM6dXNu2yjZjZDEFTHz0v5vP72/Pm/BmtPGZkLWY4rh2+W+OzHau9EaiZHgyBJRNRnA8OK8KAY1rb5jO+hRRNaIJbz7Bh7fLFR5akaUKgjqC/0X927vluUZNkJmtOEzvmQFJggEzJ2pzMang5hD/Ng1KUauRrnMyQWl6gZox2hNlwh8UsGcnOFNtoPjisCCEprW3xOV/90RvSuIIPFxLguoNKTpiJj1abkSZC2CxnRqZ55oTWJnPWNHHuha1dVT0gZpGrnJlYFVFer6qi/0i/lo0QYDDL86EzomZNCnLii/1bBZpoUgBXtC07vtuOqxTpDULStqiZBT4jF97i9MjG8cOx03m+BVqgRwXBmHZUXrC9s2m6bNPE9hVWLKUIBneBWVSyUloTm2OJQQbnBORVkdlXV6MBgZqga0aY68cHKRJXr14dH59ph5iEfaEn7bYeLKV4LpKZNtcUGPq2hHEIE93jRkl8swVSM/paA+hOZu9hmnyNSrRCXgvqXwJFq9/FdARzjZOnG1MYAYy5dJPZ1TagxkfOdJFaKo1PBTBmkU/Hixu0imwHO8MsVdfrDieWV2d9Pu0Al80mheUYkOgDdNxs5DllyGgqgFskxlgnM26a7/g0Dzk0pmi2UVaoM17TtAlnVn/segzWibxQoafVacaMcmZGDX7aqNXQpCAwU56a66bbTWa49gBzON2/tY0KFY6KzJZxtoWFhsPyyrbGt4qz6HV8LCSFucpLx17vY5o041l5sZCqTtNDAVgsBCUccDyJWYmWbPC7bjAbJ2htEaRG3OzUGLPADVtfIn5jro6ZIysik1FB0bBe1/hDr/7DWQcOX+pnevDEf8gH/9RNv5PZuya0XLqz5hoOe16bwfl0DAJtLAiIz0iU3dnFnDgrDMwwo/3mFRvXJGrcr+kFKxqUMXuFzEjHrGeDGb9ElD9rjZzC/OVfNL/pb3wgrDmBj3cLep2ADHOVMmZ8GOidH7RbFxRNzGvBoeFYY32QGydktcdGqVU2k37Xxkz+Eh/xLKdm6loZMxxowZATSSomNcYsEmVP89TljfExTPQeMVM9vDvrY5JaWGlkTzf5j6x7f8gHbi15P9PkjpcrmqhKhkMzmRnjtOXIFthj+2aYMJlB6wa1qECtyFTDySw2Pv6Hq8ycMU9LJsOmzkEH6Um7PDNRzBU1E5pf9x9OrLx9+/PLgq7wFXvW+k8Im05m7xU1SWasKGCbCdfUaXoKMWoqmrNU4Mge8mf4zVJCYAbGf2ucreQVqeUf4AyfU8/mrtwqto3fH89iYIrQPCwDF8ZV/4grYT1vR3XYvJG74ZPrpsNDZmZdRauB7HMwmXn9XRNaLu2WR7MteBlTNZo7SbRxjxbMlS28Qg+yYrz2wJx1sjFDalkWnaPW+w7Ar0Gy6WDG9gZyM3vZLL77AJmBrGc5M/68HavgaSpanfA75WXJLywyS6mv/U5m2gRmGu/1FsSEtZKv3qbB2jPTONvY4EbJMZDow4dJjPV71mpZOzPSNbox4lsi9MKbiswMcrUbM0ngloys49QFMkv6o1zPjCFEVLXpkgisMPHzP5NmOkt92XQyS723aUJei9cTuRZ0TAzgdGDOZBZlaw8CD2rEKLVQyrE1e/iQvvkoHRxpZ8Z0LYpr3yJJi1p+K3AcMyaxnfYNvLRuxiyJz5pTgvGQlQm0wIaGigr7h4dbo6XtUjSbDYuLqMagmretOaOEtu59oib1jDSAKZr4BCF0iBzazLgBDfDkiisL/HG4heV9WWZrQ5O0dDtfw6PX600nM3ytVDbLnZRiPMOPY3AnMTMFV+aAniUS/LUbWCa8XHmwMDumadPIbPff//53W9s6DtdHqQYwCoSMduhkhutq3ydqkmxYS0bFvBYX+QKz+pu3DGhs/VlOKm493ypKOebIYFMikiDrXH24/Gwrr+d0qZwZ0zVkBlcuvJDrTMy6mXMzmPkNcnrjYakfVS+89+pWe8y1c58za6zh5aqmOtY2kmmesob2LD0ajxpLRsUFL/gOC3RoSmwvy6AFjLXasKe5CFkKwrGMGa2vNbaXMYMT3YiwFTZJU9fOxswFuJ/Sw9xl7/PioZLthk91RSnZKBz9fHd1lq+YrWsUYxs9YPd+puniT6NxRbPN1dMSKnmnm+dYCckSE81TfFVNIlAmFZghNbIylPB5mHXPzOF6Q9Czw0JjBWb8hS5Xxg1mGCp0f+GoVHIyO+NCvdNkjpglgo4FLxCXArg0o9a109ZmRAIpaDGDH4kbYNrITHIgkyoyA+95IxFJWtTOyIy43Y9GopD0fvXV1paTHH9U7BakxBHh9RA8W6sTVrakzrhQ71QpUkhzLngBh4bLG/GJke49nphGE8xC6aHNZCI557Izo4Us9PvYt1l2bxjUcEj77Mxi98evUp1wG/K1H/e3jo4OC4ap8ufSX8HXe0fGVoudwGzs4EJME/PaiKloVuKKKzjROAN4AkixWGLKgl8CHHIkQlzw4ESSq1eQYCSSJ77/M7aRZAYKRnV2Zq4rX7zCMoFFJOzIHoE7hGKAPxu9h0j/7+YbKKQmXh5aauZ3muZFvNY7QcbpXPDCB7hleqPCzoyRmOKuiUg2uc6cyBwxC0IoiLZh+p4srJ/6jlmgRormT5a9MO6UA7HAimbHjcQlkcwXDo+Ojn6gb0kNsYaI7n1V6n+L6I7IFIV5izMv1DtNNkjRko68FhzabpAcGsnOenScOoQ/ZmoNLvhOpLbxcdCA6MxG7Vz32dSeU3unV/jEuts31pN4f7iRy+t00lix7f59s16NyMlkYWviyC8yG2PL2y/iBV+xLCkPhc6AqWdp5tCCT8z9IDFfX18HMsKx3fezbcVbG+d/D89G43u9wReqhBszefSNT8UHrKlejVK9yuxfTHEvKmqSrGdNZjnbiz/IOE8+dudDvvK0e26jgqHFduZq12fykTb2Zi/dqJNT2oWZJjOwBINmLXjxaSpj9pH+d1VQFjBm/pd3l6guGGMPC1/Qu/dmogazeraiEQrHh6Uge7vSB3qn6fsKMWPjtrr/EAtlejOJ80Um7yxzrBbkEwMA7EEpmDPe6Pjk9ON/jcKYGXmaXy9MvL5A03Sx5wb4Uz3y6oPnsgkMFe1X8WLrcwsxK7xsZNjoXVQXFjVJarMJ86keABYURP5I/98lZBZt+8fm25cF9v4zpm8X9//UxJKkaOjRBFz1UCoVPtIQ4Or+tO3q1du3s1nANlEwX4hwgZezYSqaySsYhCLnIw0AILEv9lipBXn4j/1vJw7rLqjWNMV65M5QMiiQ8hsf+H3z7yk7X0Tvs1V21679OPH25yO/fqH/hdQ6MQsyZglIpWc+cmBMujeKWJ3iWKecBGwXek07/DHFYPAaFMHF3wQwJt1XZnDwACvTstcAv6cU6GZcuz0+PnPltwOMSXftOg6/XPj/6tOeTSSjv0VgTGLtv8T/g5TP/maB/WLSfuXjTPirUpWq/I6lvbYqhpyt/JyTqyJI2f+qUkG6parY5AxDqrXyh+7kr0zOMN9xE5ldqwoTZHb6fy2LzK5d+kNVUC5dOzOz21c/+2NV/vjH/7l6++zM/vC/PqnKJ5/88Q/n0DNgdrkqVWbnl4+W2dCQ88N/TN6Z2ZCnoaEB/9EPD31qaLh+eTjk9Xob4DqGGuBDaJjtzb4eHrp8ne3nYW3gLrjzdfb90HVjP/6BnwF3H2oIhUINnM91TxOI9zr/EBq67vZ6m2Avt5fEc/m6F3eAsxsf3HC4Z+hyg7cJOzXkMVv3GH0yfvNeeszONly3nfw9mN3p7Y17R+LxgaaOeLwn1BoH6Qg1DLb29jb3ueGq+5p7e1sfh2jnHvw2vua+HuqjT248/1DTQDPu7L18fRA39g1fn8LfrX1TIfoAH70d+KvnMm9ukO7BUNNgHA5svXPd09PR3NvcMdWA+9355LK3iw674+Rf2b8AAAcVSURBVGnq64X+dTVc9+KH5q6Qdy0efzzsfYzdWwtd92B/73kH4vGpyw10UNcQ+x3vmMJeNg8OXR5+TBvuNfCTN7wvs0GXq9M74HLFmyZdrp4QvrUKNgyyvXu93l726fEwMTM3N9MHYhbqYls7hhsG6OiG4TtsS8sUb8flpnYfD3lb2Rc9pLVsq2vS657km72dsBcw66C/R5rY7q57TWyDq6sJTtzlHWF/NXtD+CuOuw0OhWjn+HAD33eSOj8CzFgH+3gjLT1DF85scrIZW5+Mw+eeKewafNPawJm19MLmO8hscnKSmOFlTMK19jaE4LAWVwtjNgn79U1NIo3JTtgAH7qGvfCzE/7dM2HDgS7PPbxY2H+gyWLWMjn52Ni9w/xAzJri0Fwz3hO6x52MGXwFf/USs0m81YNNFjNojRrHRrounhl6slbevUG42BYkGA9xZpPYYbrd97xexgx61gXf9Ia8cers1DAdBT1t9XqnsH1UDDisr8Ezyb6gbofgtL14tLsLP0CTawKzPvBn2J2eLs6sB8i2MmbN+DXeO9gBWsTdgVmnq3fSNdmAzGi/xwKz5ia4KrifXmhkYPjimYGLJWbxlhZi5rUxQ54D1PVhFuuIGUPT6+qEb0eIGXEaxo+dITTaNWyEmD3u7ByxmHUKzEQ962sYGvJAd6YGkFlLGbMQZwb6OYXMhmGfeCdYHmMWdzALXR6CHSa9cPJ7vwAzj5v0zOt2uz2DFZmtUddDbo/BbMAzMvK4KTTp6u2DPxoMZq0GM9g60gJcQmiXoSavx2TmfTwy4q3IzOv2ILM7UyMjyMY11TMyMljOrGPS1YXMGjzQZzQNU8+mRGZwNV7j5Ncv3p+19KGD6OgZHBx025hdtjFrmewNmcxA5yBTgDuNWhEybLNjeIiYgdG67kyiV0b3NRlnoYuYheDAhkrMWiY73cQFmh4mhcNzhMqZ9bo6+hAVnGkgji4DD+7EboSI2ScUAyZb7mBHXS3x88fN29eu3b46dd2USnGzg5hhlBFsE3e2McPPuJGYNcCHBmirYwR9BxyFzr0Fbj5j1utqCcGGUGiEhco7eKCXmOGBdmbD11ncbGHMcFdihh/KmbV2kHIPoqca6bDC42QXY9ZAzeO1eB+z8DzIL/2zqwjjyqnMbn1+6dKlq//lZgKJYjmztbURbzkztFS3jVnr2gBtxIg+AC15sdcdA9jeHTpXC3zPmYGOjQCOOx6vuwtx9+GRxMyLR9qZNbnxjM0DA26yTdyBmNE5ypl1uSaJGTjMgVY0Szi4s6PFsE2vG5vvHFjrcXvd98yTg9/57Cqw+PSLszLz0FGhgda+O8fGzcFOJzOPjRnGTYNZV09zcwf2mlghs5ZmzB28jBlTXzykp8fd1MedJTFrgmzWY2fmJWZ9QIpQjTQ3D2AMmHrc2zxQIQZMuVow1+CpH7bIY8A9YhYiZhA34Zazk7eKzD4/JzO4aZ1TnFlrWQwwc41yZgOMmdtihs0YiafLjaCa1rB3xMzLc2G4wxAl2Bcms15n3BwMucUYcFrcbIbvepEZS7MhGTKYdQl6xmMAu9T3ZdZTrmchT4X8zGSGHuUeMQt5BD3jV911p5cdZWMGTq73Dv09yb7oKGPWiR/WGDMPMQt5iBnLz/DDiJnTivlZMx6DzODXvUG4iFCHyZb0zBOiXMPjgSM6my6AGaXOTZiH45m5EU16+1joYXVAZws/j8fQlx5+Uwc9RiuTLtb5HgQ8MOVgRvdkkGdjWFaQJzTrgNAI/9DFrt/l7uBqSWUJsMQ0AT/0MRatRvdCmMDEcd87mMZ48P7d6WD9YXUAfsViQKtx8rX3Ykb1IXodFlDirH4DXephDsgsLNHJWMziXhszXm+S0/Eg7g6DWZyY0S3o8JJh85JvinXAOAuvNyep3hSYGfXmFD/ONVheb5KtwzdY14WwX/f4vr0hr4NZn+3k78bM7b3X0doBONi4Qh8kqa0oHZ6Qew2+GQiBMqzFe5s7Brnv6kMBFxFaw/3i7Ozee804+OB1w5Eh7+N4fKAn3tpHgyVedw9sxHGHkVAIPsFtiuNIRoidfoqNnrg97j4c1+jxhvqoA+6uODZ/LxRag+2tGBXwQ/yx17vWGn/s8Q62NvfG17C/8T7vIO48NYUnojONUC8h5fay1noeU2tdXm8XnnyQnfxdmbkxRpIGefkHL/9gbmBbjP3pj5C5n0fY6qXf7A882m21SKcRvjabM8/iMTbzpkLGiYym3cIGj30zO9hD5+QH2q/G47G1Zp78HZn9nqXK7PxSZXZ+OTezqnhC52P2P59V5bPP/t95mF26WhWUS+dhVhVTzsDsyqcfupO/Mvn09PGz2NWqoony+aUzPBWxc+nTqljy7zO9GSTWfqUqhrS3nAVZVapSlapUpSpVqUpVqlKV37D8f7O8ekXF8lopAAAAAElFTkSuQmCC" alt="Your Company">
            <h2 class="mt-10 text-center text-2xl font-bold tracking-tight text-gray-900"><?php echo e(__('Inicia sesión en tu cuenta')); ?></h2>
        </div>

        <div class="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
            <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

            <form class="space-y-6" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Dirección de Email -->
                <div>
                    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'email','value' => __('Correo Electrónico'),'class' => 'block text-sm font-medium text-gray-900']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Correo Electrónico')),'class' => 'block text-sm font-medium text-gray-900']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'email','class' => 'block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm','type' => 'email','name' => 'email','value' => old('email'),'required' => true,'autofocus' => true,'autocomplete' => 'username']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'email','class' => 'block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm','type' => 'email','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true,'autocomplete' => 'username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Contraseña -->
                <div>
                    <div class="flex items-center justify-between">
                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'password','value' => __('Contraseña'),'class' => 'block text-sm font-medium text-gray-900']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Contraseña')),'class' => 'block text-sm font-medium text-gray-900']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                        
                    </div>
                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'password','class' => 'block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password','class' => 'block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Recuérdame -->
                <div class="block mt-4">
                    <label for="remember_me" class="inline-flex items-center">
                        <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" name="remember">
                        <span class="ms-2 text-sm text-gray-600"><?php echo e(__('Recuérdame')); ?></span>
                    </label>
                </div>

                <div>
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 ms-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 ms-3']); ?>
                        <?php echo e(__('Iniciar Sesión')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                </div>
            </form>

            <p class="mt-10 text-center text-sm text-gray-500">
                <?php echo e(__('¿No tienes una cuenta?')); ?>

                <a href="<?php echo e(route('register')); ?>" class="font-semibold text-indigo-600 hover:text-indigo-500"><?php echo e(__('Crear una cuenta')); ?></a>
            </p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH D:\Xammp\htdocs\Proyecto_Web\resources\views/auth/login.blade.php ENDPATH**/ ?>