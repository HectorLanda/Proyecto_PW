<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CartaController;
use App\Http\Controllers\VentaController;

// Página principal con los tres botones
Route::get('/cartas', [CartaController::class, 'index'])->name('cartas.index');

// Página para listar las cartas (lo que antes era cartas.index)
Route::get('/cartas/lista', [CartaController::class, 'lista'])->name('cartas.lista'); 

// Página para crear una nueva carta
Route::get('/cartas/create', [CartaController::class, 'create'])->name('cartas.create');

// Endpoint para guardar una nueva carta
Route::post('/cartas', [CartaController::class, 'store'])->name('cartas.store');

// Página para editar una carta (renombrada a cartas.modificar)
Route::get('/cartas/{id}/modificar', [CartaController::class, 'edit'])->name('cartas.modificar');

// Endpoint para actualizar una carta
Route::put('/cartas/{id}', [CartaController::class, 'update'])->name('cartas.update');

// Endpoint para eliminar una carta
Route::delete('/cartas/{id}', [CartaController::class, 'destroy'])->name('cartas.destroy');

// Ruta para crear una nueva venta
Route::get('/ventas', [VentaController::class, 'create'])->name('ventas.create');

// Ruta para guardar la venta
Route::post('/ventas', [VentaController::class, 'store'])->name('ventas.store');

Route::get('/ventas/realizadas', [VentaController::class, 'index'])->name('ventas.realizadas');


// Página para listar las cartas (formato pokedex) 
Route::get('/cartas/pokedex', [CartaController::class, 'pokedex_lista'])->name('cartas.pokedex');


//------------------------------------------------------------------



Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';



Route::middleware('auth')->group(function () {
    Route::get('profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('profile/update', [ProfileController::class, 'update'])->name('profile.update');
});


