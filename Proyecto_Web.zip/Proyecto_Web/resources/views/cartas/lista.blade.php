<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Cartas</title>
    <link rel="stylesheet" href="{{ asset('boob.css') }}">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1 class="mb-4">Listado de Cartas</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="row">
        @foreach ($cartas as $carta)
            <div class="col-md-4 mb-4">
                <div class="card" style="width: 18rem;">
                  
                    @if($carta->imagen)
                        <img src="{{ asset('storage/' . $carta->imagen) }}" class="card-img-top" alt="{{ $carta->nombre }}">
                    @else
                        <img src="https://via.placeholder.com/150" class="card-img-top" alt="No Image">
                    @endif
                
                    <div class="card-body">
                        <h5 class="card-title">{{ $carta->nombre }}</h5>
                        <p class="card-text">{{ $carta->descripcion }}</p>
                    </div>
                   
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Precio: ${{ $carta->precio }}</li>
                        <li class="list-group-item">Categoría: {{ $carta->categoria->nombre }}</li>
                        <li class="list-group-item">Stock: {{ $carta->stock }}</li>
                    </ul>
                    
                   
                </div>
            </div>
        @endforeach
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>