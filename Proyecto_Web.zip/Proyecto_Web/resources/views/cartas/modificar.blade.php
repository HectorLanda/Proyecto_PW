<!-- resources/views/cartas/modificar.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Carta</title>
    <link rel="stylesheet" href="{{ asset('styles.css') }}">
    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const previewContainer = document.getElementById('image-preview');
                const imageElement = document.getElementById('preview-img');
                
               
                previewContainer.style.display = 'block';
                imageElement.src = e.target.result;
            };
            
            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</head>
<body>

<h1>Actualizar Carta</h1>

<form action="{{ route('cartas.update', $carta->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" id="nombre" value="{{ $carta->nombre }}" required>
    <br>

    <label for="descripcion">Descripción</label>
    <textarea name="descripcion" id="descripcion">{{ $carta->descripcion }}</textarea>
    <br>

    <label for="precio">Precio</label>
    <input type="number" name="precio" id="precio" value="{{ $carta->precio }}" step="0.01" min="0" required>
    <br>

    <label for="categoria_id">Categoría</label>
    <select name="categoria_id" id="categoria_id" required>
        @foreach($categorias as $categoria)
            <option value="{{ $categoria->id }}" @if($categoria->id == $carta->categoria_id) selected @endif>{{ $categoria->nombre }}</option>
        @endforeach
    </select>
    <br>

    <label for="stock">Stock</label>
    <input type="number" name="stock" id="stock" value="{{ $carta->stock }}">
    <br>

    <label for="imagen">Imagen</label>
    <input type="file" name="imagen" id="imagen" onchange="previewImage(event)">
    <br>

    
    <div id="image-preview" style="display: none;">
        <h3>Vista previa de la imagen:</h3>
        <img id="preview-img" src="{{ asset('storage/' . $carta->imagen) }}" alt="Vista previa de la imagen" style="max-width: 300px;">
    </div>
    <br>

    <button type="submit">Actualizar</button>
</form>

<a href="{{ route('cartas.pokedex') }}">Volver</a>

</body>
</html>
