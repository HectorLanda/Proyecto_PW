<!-- resources/views/cartas/create.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Carta</title>
   
    <link rel="stylesheet" href="{{ asset('styles.css') }}">
    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const previewContainer = document.getElementById('image-preview');
                const imageElement = document.getElementById('preview-img');
                
              
                previewContainer.style.display = 'block';
                imageElement.src = e.target.result;
            };
            
            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</head>
<body>

<h1>Crear Carta</h1>

<form action="{{ route('cartas.store') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" id="nombre" required>
    <br>

    <label for="descripcion">Descripción</label>
    <textarea name="descripcion" id="descripcion"></textarea>
    <br>

    <label for="precio">Precio</label>
    <input type="number" name="precio" id="precio" step="0.01" min="0" required>
    <br>

    <label for="categoria_id">Categoría</label>
    <select name="categoria_id" id="categoria_id" required>
        @foreach($categorias as $categoria)
            <option value="{{ $categoria->id }}">{{ $categoria->nombre }}</option>
        @endforeach
    </select>
    <br>

    <label for="stock">Stock</label>
    <input type="number" name="stock" id="stock" min="0">
    <br>

    <label for="imagen">Imagen</label>
    <input type="file" name="imagen" id="imagen" onchange="previewImage(event)">
    <br>

    
    <div id="image-preview" style="display: none;">
        <h3>Vista previa de la imagen:</h3>
        <img id="preview-img" src="" alt="Vista previa de la imagen" style="max-width: 300px;">
    </div>
    <br>

    <button type="submit">Guardar</button>
</form>


<a href="{{ route('dashboard') }}">Volver</a><br><br><br><br>


</body>
</html>
