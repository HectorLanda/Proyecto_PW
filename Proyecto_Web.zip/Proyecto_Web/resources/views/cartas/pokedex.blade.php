<!-- resources/views/cartas/pokedex.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cartas Pokémon</title>
    <link rel="stylesheet" href="{{ asset('jorge.css') }}">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            @if (session('error'))
                alert("{{ session('error') }}");
            @endif
        });
    </script>
</head>
<body>

<h1>Cartas Pokémon</h1>

@if (session('success'))
    <div>{{ session('success') }}</div>
@endif

<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Stock</th>
            <th>Imagen</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        @foreach($cartas as $carta)
        <tr>
            <td>{{ $carta->nombre }}</td>
            <td>{{ $carta->descripcion }}</td>
            <td>{{ $carta->stock }}</td>
            <td>
                @if ($carta->imagen)
                    <img src="{{ asset('storage/' . $carta->imagen) }}" alt="{{ $carta->nombre }}" style="max-width: 100px;">
                @else
                    No hay imagen
                @endif
            </td>
            <td>
                <form action="{{ route('cartas.destroy', $carta->id) }}" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta carta?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Borrar</button>
                </form>
                <a href="{{ route('cartas.modificar', $carta->id) }}">Actualizar</a>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<a href="{{ route('cartas.create') }}">Agregar nueva carta</a><br>
<a href="{{ route('dashboard') }}">Volver</a><br>
</body>
</html>
