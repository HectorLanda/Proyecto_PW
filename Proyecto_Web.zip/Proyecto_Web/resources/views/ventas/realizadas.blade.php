<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas Realizadas</title>
    <link rel="stylesheet" href="{{ asset('Pedidos.css') }}">
</head>
<body>
    <h1>Ventas Realizadas</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($pedidos as $pedido)
                <tr>
                    <td>{{ $pedido->id }}</td>
                    <td>{{ $pedido->cliente->nombre }}</td> <!-- Nombre del cliente -->
                    <td>{{ $pedido->fecha }}</td>
                    <td>${{ number_format($pedido->total, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <a href="{{ route('ventas.create') }}">Registrar Nueva Venta</a><br><br>
    <a href="{{ route('dashboard') }}">Volver</a><br><br><br>
</body>
</html>
