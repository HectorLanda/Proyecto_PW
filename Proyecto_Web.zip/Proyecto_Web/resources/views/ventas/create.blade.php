<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Venta</title>
    <link rel="stylesheet" href="{{ asset('moi.css') }}">
    <!-- Agregar jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Validar el campo de teléfono para que solo acepte números y tenga un máximo de 10 dígitos
        function validatePhone(event) {
            const input = event.target;
            input.value = input.value.replace(/[^0-9]/g, '').slice(0, 10);
        }

        // Validar el campo de nombre para que no acepte números ni caracteres especiales
        function validateName(event) {
            const input = event.target;
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }

        // Usar jQuery para habilitar el campo de cantidad cuando se marca el checkbox
        $(document).ready(function() {
            $('.carta-checkbox').change(function() {
                var cantidadInput = $(this).closest('div').find('.cantidad');
                if ($(this).is(':checked')) {
                    cantidadInput.prop('disabled', false); // Habilitar cantidad
                } else {
                    cantidadInput.prop('disabled', true); // Deshabilitar cantidad
                    cantidadInput.val(''); // Limpiar cantidad si el checkbox se desmarca
                }
            });
        });
    </script>
</head>
<body>
    <h1>Registrar Nueva Venta</h1>

    <form action="{{ route('ventas.store') }}" method="POST">
        @csrf
        <!-- Datos del cliente -->
        <fieldset>
            <legend>Información del Cliente</legend>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" required oninput="validateName(event)">
            <br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email">
            <br>
            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" id="telefono" required oninput="validatePhone(event)">
            <br>
            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion">
        </fieldset>

        <!-- Fecha del pedido -->
        <fieldset>
            <legend>Detalles del Pedido</legend>
            <label for="fecha">Fecha del Pedido:</label>
            <input type="date" name="fecha" id="fecha" required>
        </fieldset>

        <!-- Lista de cartas -->
        <fieldset>
            <legend>Seleccionar Cartas</legend>
            @foreach ($cartas as $carta)
                <div>
                    <input type="checkbox" class="carta-checkbox" name="cartas[{{ $carta->id }}][id]" value="{{ $carta->id }}" id="carta_{{ $carta->id }}">
                    <label for="carta_{{ $carta->id }}">{{ $carta->nombre }} - ${{ number_format($carta->precio, 2) }}</label>
                    <input type="number" name="cartas[{{ $carta->id }}][cantidad]" min="1" placeholder="Cantidad" class="cantidad" disabled>
                </div>
            @endforeach
        </fieldset>

        <button type="submit">Guardar Venta</button>
    </form>

    <a href="{{ route('dashboard') }}">Volver</a>

    @if (session('alert'))
        <script>
            alert('{{ session('alert') }}');
        </script>
    @endif

    @if (session('success'))
        <script>
            alert('{{ session('success') }}');
        </script>
    @endif
</body>
</html>
