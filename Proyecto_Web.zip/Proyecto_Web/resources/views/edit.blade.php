@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Editar Perfil</h1>
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <form method="POST" action="{{ route('profile.update') }}">
        @csrf
        <!-- Campos del formulario de perfil -->

        <button type="submit" class="btn btn-primary">Actualizar Perfil</button>
    </form>
</div>
@endsection
