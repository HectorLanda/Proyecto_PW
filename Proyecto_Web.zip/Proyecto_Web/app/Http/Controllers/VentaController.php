<?php

namespace App\Http\Controllers;

use App\Models\Carta;
use App\Models\Cliente;
use App\Models\Pedido;
use App\Models\DetailsPedido;
use Illuminate\Http\Request;

class VentaController extends Controller
{
  
    public function index()
    {
        
        $pedidos = Pedido::with('cliente')->get();

     
        return view('ventas.realizadas', compact('pedidos'));
    }

 
    public function create()
    {
        $cartas = Carta::all(); 
        return view('ventas.create', compact('cartas')); 
    }

   
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:100',
            'fecha' => 'required|date',
            'cartas' => 'required|array',
            'cartas.*.id' => 'required|exists:cartas,id',
            'cartas.*.cantidad' => 'required|integer|min:1',
        ]);

        
        foreach ($request->cartas as $carta) {
            if ($carta['cantidad'] > 0) {
                $cartaDB = Carta::find($carta['id']);
                if ($cartaDB->stock < $carta['cantidad']) {
                    return back()->with('alert', 'No hay suficientes cartas disponibles en el almacén.');
                }
            }
        }

     
        $cliente = Cliente::updateOrCreate(
            ['nombre' => $request->nombre],
            [
                'email' => $request->email,
                'telefono' => $request->telefono,
                'direccion' => $request->direccion,
            ]
        );


        $pedido = new Pedido();
        $pedido->cliente_id = $cliente->id;
        $pedido->fecha = $request->fecha;
        $pedido->estado = 'Completado';
        $pedido->total = 0; 
        $pedido->save();

        $total = 0;

      
        foreach ($request->cartas as $carta) {
            if ($carta['cantidad'] > 0) {
                $cartaDB = Carta::find($carta['id']);
                $detalle = new DetailsPedido();
                $detalle->pedido_id = $pedido->id;
                $detalle->carta_id = $cartaDB->id;
                $detalle->cantidad = $carta['cantidad'];
                $detalle->precio_unitario = $cartaDB->precio;
                $detalle->save();

                $total += $cartaDB->precio * $carta['cantidad'];

              
                $cartaDB->stock -= $carta['cantidad'];
                $cartaDB->save();
            }
        }

       
        $pedido->total = $total;
        $pedido->save();

        return redirect()->route('ventas.create')->with('success', 'Venta registrada correctamente.');
    }
}
