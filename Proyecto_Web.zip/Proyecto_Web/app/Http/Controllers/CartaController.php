<?php

namespace App\Http\Controllers;

use App\Models\Carta;
use App\Models\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CartaController extends Controller
{
   
    public function index()
    {
        return view('cartas.index');
    }

  
    public function lista()
    {
        $cartas = Carta::all();
        return view('cartas.lista', compact('cartas'));
    }

    public function pokedex_lista() 
    { 
        $cartas = Carta::all(); 
        return view('cartas.pokedex', compact('cartas')); 
    }

    
    public function create()
    {
        $categorias = Categoria::all();
        return view('cartas.create', compact('categorias'));
    }

   
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:100',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric',
            'categoria_id' => 'required|exists:categorias,id',
            'stock' => 'nullable|integer',
            'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $carta = new Carta();
        $carta->nombre = $request->nombre;
        $carta->descripcion = $request->descripcion;
        $carta->precio = $request->precio;
        $carta->categoria_id = $request->categoria_id;
        $carta->stock = $request->stock;

        
        if ($request->hasFile('imagen')) {
            $imagenPath = $request->file('imagen')->store('cartas_imagenes', 'public');
            $carta->imagen = $imagenPath;
        }

        $carta->save();

        return redirect()->route('cartas.pokedex')->with('success', 'Carta agregada correctamente.');
    }

   
    public function edit($id)
    {
        $carta = Carta::findOrFail($id);
        $categorias = Categoria::all();
        return view('cartas.modificar', compact('carta', 'categorias'));
    }

  
    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string|max:100',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric',
            'categoria_id' => 'required|exists:categorias,id',
            'stock' => 'nullable|integer',
            'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $carta = Carta::findOrFail($id);
        $carta->nombre = $request->nombre;
        $carta->descripcion = $request->descripcion;
        $carta->precio = $request->precio;
        $carta->categoria_id = $request->categoria_id;
        $carta->stock = $request->stock;

       
        if ($request->hasFile('imagen')) {
            $imagenPath = $request->file('imagen')->store('cartas_imagenes', 'public');
            $carta->imagen = $imagenPath;
        }

        $carta->save();

        return redirect()->route('cartas.pokedex')->with('success', 'Carta actualizada correctamente.');
    }

 
    public function destroy($id)
    {
        $carta = Carta::findOrFail($id);

        $related = DB::table('details_pedidos')->where('carta_id', $id)->exists();

        if ($related) {
            Session::flash('error', 'Esta carta no puede eliminarse porque hay clientes interesados en ella.');
            return redirect()->route('cartas.pokedex');
        }

        $carta->delete();
        return redirect()->route('cartas.pokedex')->with('success', 'Carta eliminada correctamente.');
    }
}
