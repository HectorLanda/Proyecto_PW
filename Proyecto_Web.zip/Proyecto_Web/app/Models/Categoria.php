<?php

namespace App\Models;

use App\Models\Categoria; 

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;

    protected $fillable = ['nombre', 'descripcion'];

    
    public function cartas()
    {
        return $this->hasMany(Carta::class);
    }
}
