<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetailsPedido extends Model
{
    use HasFactory;

   
    protected $table = 'details_pedidos';

 
    protected $fillable = ['pedido_id', 'carta_id', 'cantidad', 'precio_unitario'];

  
    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

   
    public function carta()
    {
        return $this->belongsTo(Carta::class);
    }
}