<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class cartas extends Migration
{
    
    public function up(): void
    {
        Schema::create('cartas', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio', 8, 2);
            $table->unsignedBigInteger('categoria_id');
            $table->integer('stock')->default(0);
            $table->binary('imagen')->nullable();
            $table->timestamps();
        
            $table->foreign('categoria_id')->references('id')->on('categorias');
        });
    }

    
    public function down(): void
    {
        Schema::dropIfExists('cartas');
    }
};
